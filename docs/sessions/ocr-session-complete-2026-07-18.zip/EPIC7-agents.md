# EPIC 7 — Always-On Agents (Hermes / Jarvis → CI/CD End Goal)
**Layer 3/5. Outcome:** agents run continuously; the CI/CD pipeline is the
qualification gate; Matt's role compresses to decisions and merges.
**Naming (so the vocabulary is fixed):**
- **Jarvis** = the interactive co-architect (these sessions + CC): plans,
  builds, reviews WITH Matt present.
- **Hermes** = the background messengers: scheduled + event-triggered agents
  that run WITHOUT Matt present and report back through Linear/PRs.
**The loop (Matt's own framing, made mechanical):** brain defines law →
stories define acceptance criteria → agents execute stories → pipeline
qualifies against law + AC → fail = rinse/repeat automatically → pass =
PR awaiting ONE human action: Matt's merge. The human gate never leaves.

---

### Feature 7.1 — Hermes v0: what runs always, starting this weekend
*(No new infrastructure — activating what exists.)*
- **S-7.1.1** Claude GitHub App as standing reviewer *(1pt, M)*
  Given claude.yml + claude-code-review.yml already in WKRP, when verified
  active and propagated to OSE, then every PR gets an agent review without
  invocation — the first always-on agent, already installed.
- **S-7.1.2** Nightly Hermes suite *(2pts, CC)*
  Given the tiered tests, when a scheduled workflow runs nightly (full
  journeys both devices, display long-run, drift scan, manifest preflight,
  cross-app canary), then failures open Linear issues automatically with the
  failing spec named. The suite that never gets skipped because nobody runs it.
- **S-7.1.3** Materialization watch *(1pt, CC)*
  Given the SharedReport cron, when a phase errors, then the structured log
  line becomes a Linear issue (label: hermes-alert) — the first
  production-watching agent, closing the "armor in front, nothing behind"
  observability gap for the surface that earns money.

### Feature 7.2 — Hermes v1: Linear-dispatched execution
*The "agents running all the time" mechanism.*
- **S-7.2.1** agent-ready protocol *(1pt, M)*
  Given the backlog in Linear, when a story carries label `agent-ready`, its
  AC in Given/When/Then, and all blockers closed, then it is eligible for
  autonomous pickup. Matt applies the label — labeling IS the delegation act.
- **S-7.2.2** Dispatcher on Bloodraven *(5pts, CC)*
  Given a scheduled workflow (e.g. every 2h), when it queries Linear for
  agent-ready issues, then for each: fresh worktree, headless Claude Code
  run scoped to that one story (one session = one atomic task — the rule,
  automated), branch + PR opened with the story linked, issue moved to
  In Review. **CCR flag: human gate — first activation supervised; kill
  switch = removing the schedule.**
- **S-7.2.3** Qualification = the pipeline *(2pts, CC)*
  Given a Hermes PR, when CI runs (invariant gates, tier-1, touched-surface
  journeys, drift guard, conformance), then red = agent gets the failure
  log as a follow-up run (rinse/repeat, max 2 retries, then label
  needs-human); green = PR sits awaiting Matt's merge. Branch protection
  (S-4.2.1) is the precondition — REQUIRED before S-7.2.2 ever runs.
- **S-7.2.4** Morning brief *(2pts, CC)*
  Given overnight Hermes activity, when Matt opens Linear at coffee, then
  one roll-up issue summarizes: PRs awaiting merge, retries exhausted,
  alerts raised. MEMENTO-aligned: the system reports; nothing depends on
  recall.

### Feature 7.3 — Hermes v2: WKRP ops agents (the original vision)
*The Scout/Freshness/Deploy/Ops crew from the curation business — same
dispatcher, different queue. Gated on: first paying venue.*
- **S-7.3.1** Freshness queue *(3pts)* — per-venue refresh cadence as
  scheduled Linear issues; Scout drafts candidate lists into the issue;
  Matt approves (taste stays human); Deploy pushes via the venue's licensed
  system API. **CCR flags: Rockbot/Soundtrack partner API access confirmed
  first; licensing posture per the standing doctrine.**
- **S-7.3.2** Ops automation *(2pts)* — invoice + check-in cadence per
  client through the connected stack, triggered by the same scheduler.

---

## Sequencing
1. F7.1 activates DURING the weekend (S-7.1.1 is minutes; 7.1.2/7.1.3 are
   Sunday-PM candidates if the blocks hold — else week 1).
2. F7.2 is week 1–2, AFTER branch protection + conformance keystone
   (E4-F4.1.1) — the dispatcher must inherit law, not precede it.
3. F7.3 waits for the first paying venue — agents serve the business,
   not the other way around.

Total: 9 stories, ~19 points. Two CCR human gates + two external gates
(partner API, first venue).

## The end state, one paragraph
Friday night Matt labels three stories agent-ready. Saturday 6 AM Hermes has
three PRs open, CI green on two, one in retry with the failure named. Matt
merges two over coffee, reads the brief, unlabels the third pending a
decision. The brain holds the law, Linear holds the queue, the pipeline holds
the gate, Bloodraven holds the runtime, and the only irreplaceable component
is judgment — which is the one thing that was never supposed to be automated.
