# Design work — where it lives
- ose_frontend_spectrum_scrum.html (HERE) — the surface-by-surface Design/Testing/PO
  breakdown. This is the design source the epics and Tier-1 manifests trace to.
- ocr-architecture-breakdown.html — in PROJECT STORAGE (auto-mounted in any project
  session). Its operative design content is already implemented in this archive:
  tier matrix → DEPTH_SECTIONS in flywheel/report-depth.ts; identity layers →
  the repo-wall ADR story; phase model → the attendee arc.
- ose-staging-dashboard-v2.html — in PROJECT STORAGE. Frozen builder surface,
  reference only ("do not touch" per the spectrum scrum).
- Two-theme refactor (theme-wkrp / theme-ose) — DESIGN DECISION recorded in
  MANIFEST + BACKLOG S-1.1.5; deliberately not yet code (CCR gate on OSE adoption).
