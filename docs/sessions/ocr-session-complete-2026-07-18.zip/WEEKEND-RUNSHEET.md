# WEEKEND RUNSHEET — Jul 18–19, 2026
**Scope discipline:** the weekend lands the ~27 points of ready-to-land +
wiring work. It does NOT attempt the full 6-epic program (~66 pts). If a
session slips, CUT from the bottom of its block — never add.
**CC rules in force:** one session = one atomic task. CC fights twice →
terminal. Kill worktrees between sessions. Zips live beside the repos; each
session's first move is copying its files in.

---

## FRIDAY NIGHT (setup, ~45 min, no code)
**F-0. Linear import (one CC session).** Prompt:
> Read BACKLOG-scrum.md, EPIC5-seamlessness.md, EPIC6-h3-ncr.md,
> DECISION-AND-STORIES.md, EPIC7-agents.md. Using the Linear MCP: create
> project "Consolidation + Flywheel Launch" on the OCR team, one parent issue
> per Epic (1–7) with the epic's features/stories as markdown checklists in
> the description, and individual sub-issues for every story tagged
> [weekend] in the runsheet, estimate = points, label "agent-ready" where the
> story is marked ready-to-land. Link blockers per the sequencing sections.
**F-1. Branch protection (5 min, browser, S-4.2.1).** Both product repos:
required status checks + no force-push. Do this BEFORE the weekend's merges —
the gates protect the sprint itself.

## SATURDAY AM — Foundations (Epic 1)
- **S-1.1.1 [weekend]** CC: "Copy packages/ui from ocr-ui-package.zip into
  the monorepo, pnpm install, run `pnpm --filter @ocr/ui test` — 17/17 —
  commit." *(2pts)*
- **S-1.2.1 [weekend]** CC: "Apply ose-extraction.zip per MIGRATION.md:
  templates in, pages.ts replaced, wrangler Text rule added, tsc clean,
  existing UI smoke green, commit." *(2pts)*
- **S-1.1.2 [weekend]** CC: "Add GET /ui.css to the WKRP router via
  serveCss() from @ocr/ui; assert one :root; commit." *(1pt)*

## SATURDAY PM — Test rails (Epic 2)
- **S-2.1.1 + S-2.1.2 [weekend]** two CC sessions: land tier1-smoke in WKRP
  then OSE per README wiring; suites green. *(4pts)*
- **S-2.1.3 [weekend]** CC: static preflight into both lint stages. *(1pt)*
- **S-2.2.1 [weekend]** CC: "Apply ose-client-ready renderPostEventHtml +
  handler patch; run the 4-test harness in repo CI; commit." *(3pts)*
- **S-2.2.2 + S-2.2.3 [weekend]** CC: seed fixtures SQL into CI seed; land
  journey-attendee-arc; green on one mobile project minimum. *(3pts)*

## SUNDAY AM — Revenue leg (Epic 3)
- **S-3.1.1 [weekend]** CC: land lib/report-depth.ts + its 8 tests. *(2pts)*
- **S-3.1.2 [weekend]** CC: optional depth/sponsor_id claims in mint;
  verify tolerates absence; legacy defaults tested. *(2pts)*
- **S-3.1.3 [weekend]** CC: patch single-event read handler per the patch
  block; response = {depth, report, upgrade?}. *(1pt)*
- **S-3.2.1 [weekend]** CC: land tier-equity.invariant.spec.ts in
  gate-tests; static half must pass untouched. *(1pt)*
- **S-3.3.1 + S-3.3.2 [weekend]** CC: mint four fixture tokens in seed;
  land sharedreport-depth.spec.ts; green. *(4pts)*

## SUNDAY PM — H3 launch + policy (Epics 6/3)
- **S-6.1.1 [weekend]** CC: h3-tagging.ts in; migration adds nullable
  h3_res9/h3_res7 to venues; backfill existing venues; 8/8 tests. *(2pts)*
- **S-6.1.2 [weekend]** CC: denormalize cells into nightly aggregates;
  pipeline-invariants extended; **tier-equity static must still pass**. *(2pts)*
- **S-6.3.1a/b [weekend]** CC: corridor-map.ts in; premium branch includes
  map SVG + suppressed → _meta; journey extended (local/mid never contain
  corridor-map markup). *(3pts)*
- **S-6.3.1c [weekend]** CC: hot-path guard static test (no h3 imports in
  scan path). *(1pt)*
- **S-3.5.1 [weekend]** CC: mint flow offers Free/Premium only; mid claim
  dormant-but-valid. *(1pt)*

## SUNDAY EVENING — Close (30 min, Matt)
- Run both full CI pipelines once, green end to end.
- Sunday-cut review: anything not green moves to next week in Linear —
  recorded, not remembered.
- Send Tom the resolution-floor question (S-6.1.3 text is in
  DECISION-AND-STORIES.md) — 5-minute email, unblocks the report.

## EXPLICITLY NOT THIS WEEKEND
Template migration ×9 (S-1.1.3), two-theme refactor, Pact, conformance
keystone (S-4.1.1), all of Epic 5, upgrade rendering (S-3.4.1). They're in
Linear with blockers set. The weekend makes the assessed system and the real
system the SAME system — that was the standing critique; this closes it.
