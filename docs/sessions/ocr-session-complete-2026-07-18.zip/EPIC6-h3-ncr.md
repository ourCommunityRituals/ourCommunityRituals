# EPIC 6 — H3 as NCR Substrate
**Layer 3. Gate (inherited, unchanged): Premium corridor features build when
corridor DATA exists, not when a calendar date arrives. Only F6.1 is
pre-gate — deliberately minimal capture-time work so the data accumulates
correctly from day one.**
**Outcome:** NCR becomes computable — nodes are cells, corridors are cell
sets, rings are gridRing — and the privacy doctrine becomes a testable
resolution floor.

---

### Feature 6.1 — Capture-time cell tagging *(PRE-GATE — cheap, load-bearing)*
- **S-6.1.1** Venue/event H3 columns *(2pts, CC)*
  Given venues carry lat/lon, when an event/venue is created or updated, then
  h3_res9 (venue) and h3_res7 (corridor-scale) cells are computed and stored.
  Computation happens at creation time (admin flow or precomputed seed), NOT
  per-scan in the Worker hot path; h3-js stays out of the request cycle.
  Migration adds nullable columns; existing venues backfilled from lat/lon.
- **S-6.1.2** Denormalize cells into scan aggregates *(2pts, CC)*
  Given the nightly materialization, when aggregates are written, then rows
  carry the event's h3 cells alongside corridor_id (label retained — cells
  AUGMENT, they don't replace, until F6.3). AC: pipeline-invariants spec
  extended; ingest path remains tier-blind (Invariant #5 static check must
  still pass — cells are geography, not tiers).
- **S-6.1.3** Resolution-floor invariant candidate *(1pt, M)*
  Given the privacy doctrine "stripped to corridor level," when drafted as a
  rule — exports never below res N; no cell published under K scans — then it
  goes to Tom as a precise question and to the brain as a candidate invariant.
  **CCR flag: human gate ×2 — Tom's opinion AND the sunset-policy slot
  (retire/merge one to add one).**

### Feature 6.2 — Corridor computation *(POST-GATE: requires multi-venue data)*
- **S-6.2.1** Corridor-as-cell-set definition *(3pts, CC)*
  Given tagged aggregates across 2+ venues, when corridors are defined as
  contiguous mixed-resolution cell sets in a brain-adjacent config (NCR yaml,
  per the promotion proposal), then corridor_id resolves FROM cells and the
  hand label becomes a display name.
- **S-6.2.2** Crossing detection as cell-set intersection *(3pts, CC)*
  Given session-scoped anonymous signals at events in different cell sets,
  when the materialization phase computes crossings, then "Beverly signals at
  Blue Island events" is a query with a test, not a narrative.
- **S-6.2.3** gridRing ring primitive *(2pts, CC)*
  Given a node cell, when ring analysis runs gridDisk/gridRing over the
  aggregate layer, then ring emergence has a computable definition for OER
  (2028 horizon — this story only proves the primitive on real data).

### Feature 6.3 — The front-end expression: Premium corridor map *(POST-GATE)*
- **S-6.3.1** Hex map on SharedReport Premium *(5pts, CC)*
  Given premium depth and tagged data, when the report renders, then a hex
  density map (h3-js + lightweight map lib, desktop/tablet-first per the
  spectrum scrum) shows the sponsor's corridor reach. Depth-gated by
  report-depth (premium section only); resolution floor enforced at render.
  AC: wrong depth never receives the map data — asserted in
  sharedreport-depth journey.
- **S-6.3.2** Suppression at the floor *(2pts, CC)*
  Given cells under K scans, when the map renders, then those cells render as
  suppressed (present but unquantified) and _meta.suppression_reasons records
  why — the privacy dial visible and honest.

---

## Sequencing
1. F6.1 now (pre-gate, ~5pts) — data correctness compounds from first scan
2. F6.2 when 2+ venues produce recurring data (the gate, unchanged)
3. F6.3 with F6.2 — the map is the last mile, not the first

Total: 8 stories, ~20 points. Two human gates (Tom + sunset slot).

## What this epic refuses to do
No H3 in the scan hot path. No replacing corridor labels before cells earn it
with data. No map before the gate. No new invariant without retiring one.
The substrate raises the ceiling; it does not jump the queue.
