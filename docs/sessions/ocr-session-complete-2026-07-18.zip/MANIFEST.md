# OCR Session Deliverables — 2026-07-17/18 (complete)
One archive, everything from this session. Apply order matches the runsheet.

## Program documents (root of this archive)
- WEEKEND-RUNSHEET.md — session-by-session execution plan, Jul 18–19, with CC prompts (START HERE; F-0 = Linear import)
- BACKLOG-scrum.md — Epics 1–4: consolidation + flywheel (23 stories, ~46pts)
- EPIC5-seamlessness.md — front-end seamlessness horizon (15 stories, ~32pts)
- EPIC6-h3-ncr.md — H3/NCR substrate epic (8 stories, ~20pts; F6.1/F6.3 pulled to launch)
- EPIC7-agents.md — Hermes/Jarvis always-on agents → CI/CD end goal (9 stories, ~19pts)
- corridor-map-launch-day.svg — the actual day-one Premium map (Blue Island cell live, 6 ring cells suppressed)

## Code packages (each has its own README/MIGRATION)
1. ocr-ui-package.zip — @ocr/ui: tokens, shared stylesheet (~92% CSS reduction), partials incl. emptyState, drift guard, 17/17 tests, Playwright e2e spec [Sat AM]
2. ose-extraction.zip — pages.ts 3,307→939 lines, 7 templates byte-identical 7/7, wrangler Text rule [Sat AM]
3. tier1-smoke.zip — one parameterized spec, 16 pages both apps, manifests verified 16/16 vs real templates [Sat PM]
4. ose-client-ready.zip — post-event renderer (4/4 tests incl. XSS), attendee-arc journey spec, relative-dated seed fixtures [Sat PM]
5. flywheel.zip — report-depth lib (8/8 strict), tier-equity invariant spec (static half PASSES live repo), sponsor/admin depth journey, FLYWHEEL.md stage map [Sun AM]
6. h3-launch.zip — h3-tagging + corridor-map (8/8 with real h3-js, Eagles Hall ground truth res9 89266454447ffff), DECISION-AND-STORIES.md (gate override + Free/Premium minting policy record) [Sun PM]
7. ocr-ui-slimdown.zip — earlier superset of #1 kept for reference (examples/dashboard.slimmed.html)

## Standing decisions recorded this session
- Two themes not one skin (OSE light/blue is deliberate; @ocr/ui → primitives + themes)
- Music seam frozen: GET /api/events/:id/music is the only cross-repo runtime boundary; Pact belongs there only
- Free + Premium launch = MINTING POLICY (three-rung ladder stays; Mid dormant)
- CCR corridor gate overridden by Matt: capture-time tagging makes the map real day one
- Invariant #6 holds: money moves off-platform, no billing code
- Outstanding human gates: Tom resolution-floor (urgent), shared-package ADR, revocation mechanics, sunset policy
