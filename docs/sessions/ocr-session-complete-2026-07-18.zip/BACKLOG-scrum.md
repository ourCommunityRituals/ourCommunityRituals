# OCR Backlog — Consolidation + Flywheel
Format: Epic → Feature → Story. AC in Given/When/Then. Points: Fibonacci.
Owner: Matt (M) or Claude Code session (CC). CCR flags carry the human gate.
Status: `ready-to-land` = code exists in delivered zips, story = apply + verify.

---

## EPIC 1 — Fleet UI Consolidation
**Layer 3. Outcome:** one design system, two themes, UI iteration cheap enough
for a solo operator. **Pulse gate:** none — infrastructure, land ASAP.

### Feature 1.1 — @ocr/ui package lands in the monorepo
- **S-1.1.1** Add `packages/ui` to workspace *(2pts, CC, ready-to-land)*
  Given the pnpm workspace with `packages/flags`, when `packages/ui` is copied
  in and `pnpm install` runs, then `pnpm --filter @ocr/ui test` passes 17/17
  and `tsc --noEmit` on src is clean.
- **S-1.1.2** Serve `/ui.css` from the WKRP worker *(1pt, CC)*
  Given the WKRP router, when GET `/ui.css` is requested, then the shared
  stylesheet returns with `text/css`, 24h cache, and exactly one `:root`.
- **S-1.1.3** Migrate the 9 WKRP templates to the shared sheet *(5pts, CC)*
  Given each template, when its inline `<style>` is replaced by
  `<link rel="stylesheet" href="/ui.css">` (+ ≤400 chars page-specific CSS),
  then visual parity holds on iPhone 13 + Pixel 5 projects and the drift guard
  reports 0/9 findings. Flip each page's `sharedSheet: true` in the Tier-1
  manifest as it migrates.
- **S-1.1.4** Wire drift guard into WKRP CI *(2pts, CC)*
  Given `ci.yml`, when the lint stage runs `checkTemplate` over
  `src/templates/`, then any re-inlined `:root` or >400-char style block fails
  the build. **Invariant #13:** register the check location in the brain.
- **S-1.1.5** Refactor to primitives + two themes *(3pts, CC)*
  Given `@ocr/ui`, when split into core (reset, tap targets, empty-state,
  escaping, contrast) + `theme-wkrp` (dark/orange) + `theme-ose` (light/blue
  #4361ee), then WKRP consumes core+wkrp with zero visual change and OSE can
  adopt core+ose later without recoloring. **CCR flag:** OSE theme adoption is
  a separate human-gated decision; do not migrate OSE pages in this story.

### Feature 1.2 — OSE pages extraction
- **S-1.2.1** Apply the byte-identical extraction *(2pts, CC, ready-to-land)*
  Given `ose-extraction.zip`, when templates land in `src/templates/`,
  `pages.ts` is replaced (3,307→939 lines), and the `[[rules]] type="Text"`
  block is added to wrangler.toml, then `tsc --noEmit` passes and all 7 page
  routes render byte-identically (smoke: existing UI suite green).
- **S-1.2.2** ADR: shared packages across the repo wall *(1pt, M)*
  Given the legal-wall doctrine and the existing `@ocr/flags` precedent, when
  the ADR states "packages with no identity, no data access, no persistence may
  cross; anything touching data/identity may not," then it is committed to
  OCR-docs and referenced from invariant #9's notes. **CCR flag: human gate —
  this is a legal-wall interpretation; Matt approves wording.**

---

## EPIC 2 — E2E Consolidation Through CI/CD
**Layer 4. Outcome:** three-tier test pyramid; per-page cost near zero at the
base, human effort reserved for the four business surfaces.

### Feature 2.1 — Tier-1 parameterized smoke
- **S-2.1.1** Land suite in WKRP *(2pts, CC, ready-to-land)*
  Given `tier1-smoke.zip` in `tests/e2e/smoke/`, when
  `SMOKE_APP=wkrp npx playwright test tier1.spec.ts --project="Mobile Safari"`
  runs in the e2e job, then all non-fixture routes pass in ≤2 min.
- **S-2.1.2** Land suite in OSE with admin auth *(2pts, CC, ready-to-land)*
  Given the ui-smoke config's `extraHTTPHeaders`, when `SMOKE_ADMIN_READY=1`
  is set, then the authed `/admin` route runs and the suite is green.
- **S-2.1.3** Static preflight in both lint stages *(1pt, CC)*
  Given `static-check.test.ts`, when run with `OSE_TPL`/`WKRP_TPL` in lint,
  then manifest/template drift fails in seconds without a browser.
- **S-2.1.4** Retire `page-endpoints.smoke.spec.ts` via process *(1pt, M)*
  Given Tier-1 is its superset, when retirement follows **Invariant #10
  deprecation_lock** (not a quiet delete), then the spec is removed with a
  recorded decision.

### Feature 2.2 — Attendee arc (Poster → Pre/Event/Post)
- **S-2.2.1** Apply post-event renderer + handler patch *(3pts, CC, ready-to-land)*
  Given `ose-client-ready.zip`, when `renderPostEventHtml` + the next-event
  query land, then `/events/:id` in post phase renders recap, return loop
  (next-at-venue or `/public` fallback), email CTA to
  `/forms/:id?type=email`, and the anonymity affordance. 4/4 harness tests
  reproduced in repo CI. `renderMinimalPhaseHtml` retained (Invariant #10).
- **S-2.2.2** Seed phase fixtures in CI *(1pt, CC)*
  Given `SEED-FIXTURES.sql` relative-dated rows, when the seed script runs,
  then `SMOKE_EVENT_{PRE,LIVE,POST}` resolve and never rot.
- **S-2.2.3** Land attendee-arc journey spec *(2pts, CC, ready-to-land)*
  Given the fixtures, when `journey-attendee-arc.smoke.spec.ts` runs on both
  mobile projects, then all five journeys pass including next-event
  click-through and email form landing.

### Feature 2.3 — Pact at the frozen music seam
- **S-2.3.1** OSE consumer pact for `GET /api/events/:id/music` *(3pts, CC)*
  Given OSE does not yet consume the seam, when a consumer test defines the
  expected shape against a Pact mock in the vitest lane, then the pact file
  generates in CI. **CCR flag:** PactFlow free tier vs repo-artifact exchange —
  Matt decides broker model before wiring.
- **S-2.3.2** WKRP provider verification *(3pts, CC)*
  Given the pact, when WKRP CI verifies it against `wrangler dev`/Miniflare,
  then seam drift fails WKRP's build before OSE ever wires the call. Dual-boot
  cross-app e2e demoted to nightly canary only.

---

## EPIC 3 — SharedReport Depth (Flywheel Revenue Leg)
**Layer 3/4. Outcome:** Local/Mid/Premium is enforced in code; the upgrade
mechanism exists; Invariant #5 moves toward `live`. **Pulse framing:** this is
the Local-tier proof line — the "one real sponsor, one real report" gate.

### Feature 3.1 — Depth gating in the read path
- **S-3.1.1** Land `lib/report-depth.ts` *(2pts, CC, ready-to-land)*
  Given `flywheel.zip`, when the module lands, then 8/8 tests pass compiled
  under `--strict` (roles, legacy default, scoping, fail-closed, additive
  ladder, equity-by-construction).
- **S-3.1.2** Extend token claims: optional `depth` + `sponsor_id` *(2pts, CC)*
  Given `mintSignedLinkToken`, when the optional claims are added and verify
  tolerates their absence, then legacy tokens resolve (admin/bar_owner→premium,
  sponsor→local) and new sponsor links carry organizer-chosen depth.
- **S-3.1.3** Patch single-event read handler *(1pt, CC)*
  Given the patch block, when responses return `{depth, report, upgrade?}`,
  then Local/Mid omit locked sections and include `upgrade.locked_sections`.

### Feature 3.2 — Invariant #5 registration
- **S-3.2.1** Land `tier-equity.invariant.spec.ts` *(1pt, CC, ready-to-land)*
  Given the two-half spec, when run in gate-tests, then static half passes
  (already verified 4/4 against the real ingest path) and unit half passes.
- **S-3.2.2** Register in the brain *(1pt, M)*
  Given `architectural-invariants.yaml`, when invariant 5's `test_file` names
  the spec and #13's location standard is satisfied, then conformance sees the
  enforcement. **CCR flag: human gate — status change partial→live is Matt's
  call after first green CI run.**

### Feature 3.3 — Sponsor/Admin journey (resurrects archived coverage)
- **S-3.3.1** Mint fixture tokens in CI seed *(2pts, CC)*
  Given the seed step, when four tokens are minted (admin, sponsor-local,
  sponsor-mid, other-event), then `SMOKE_RPT_*` env vars are exported.
- **S-3.3.2** Land `sharedreport-depth.spec.ts` *(2pts, CC, ready-to-land)*
  Given the fixtures, when the journey runs, then 401/403/full/local/mid/
  equity assertions pass — the revenue surface is covered again.

### Feature 3.4 — Upgrade rendering (presentation)
- **S-3.4.1** SHARED_REPORT_HTML renders locked sections *(3pts, CC)*
  Given `upgrade.locked_sections`, when the report shell renders a Local view,
  then locked sections appear as inline blurred previews with "upgrade to see
  X" — not a popup (April 7 CCR decision). AC includes mobile single-scroll on
  375px.

---

## EPIC 4 — Governance Conformance & Operational Resilience
**Layer 1/5. Outcome:** the brain's law is self-enforcing; the solo-operator
single points of failure are mitigated.

### Feature 4.1 — Conformance keystone
- **S-4.1.1** Extend brain-contract-check with the conformance rule *(5pts, CC)*
  Given `architectural-invariants.yaml`, when the check walks every `live`
  invariant and verifies its `test_file` exists AND is invoked by an active
  workflow in every `applies_to` repo, then a repo dropping a check fails its
  own contract check. (Universalizes OCR-53.)
- **S-4.1.2** Register the new checks *(1pt, M)* — drift guard, Tier-1
  manifests, static preflight, tier-equity spec all get brain locations per
  Invariant #13.

### Feature 4.2 — Resilience
- **S-4.2.1** Branch protection on both product repos *(1pt, M)*
  Given solo-admin override risk, when required-status-checks + no-force-push
  are set, then bypassing gates requires a deliberate settings change, not a
  tired click. **CCR flag: human gate.**
- **S-4.2.2** Runner degraded-mode runbook *(2pts, M)*
  Given Bloodraven as sole runner, when the runbook defines what ships (and
  what never ships) while the runner is down, then the 11-PM-Thursday decision
  is pre-made. **CCR flag: human gate.**
- **S-4.2.3** Invariant sunset policy *(1pt, M)*
  Given growth pressure toward #15/#16, when the policy requires retiring or
  merging one invariant per addition (legal/privacy exceptions only), then the
  brain stays law, not bureaucracy. **CCR flag: human gate.**

---

## Sequencing (dependency order, not calendar)
1. E1-F1.1.1 + E1-F1.2.1 (land the foundations — everything else references them)
2. E2-F2.1 (smoke rails) → E2-F2.2 (attendee arc green)
3. E3-F3.1 → F3.2 → F3.3 (depth, invariant, journey — the revenue leg)
4. E4-F4.1.1 (conformance keystone) → F4.2 (resilience)
5. E1-F1.1.3/1.1.5 (template migration + themes — steady-state, interruptible)
6. E2-F2.3 (Pact) and E3-F3.4 (upgrade rendering) — after the above are green

Total: 23 stories, ~46 points. Ready-to-land stories: 8 (≈16 points of
already-verified work awaiting apply).
