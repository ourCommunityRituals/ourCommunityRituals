# EPIC 5 — Front-End Seamlessness Through Features
**Sequenced strictly AFTER Epics 1–4 (consolidation + flywheel) are green.**
**Layer 3/4. Outcome:** the flywheel feels like ONE continuous experience per
persona (attendee, organizer, sponsor). Definition of a seam: any moment where
a human must carry context the system dropped. Every story below closes one.

**Standing constraints honored throughout:**
- Invariant #1 — no accounts, ever. Continuity is phase-driven (server) or
  device-local (client). Zero server-side linkage of person↔behavior.
- Invariant #6 — inert monetization: upgrade affordances route to humans,
  never to billing.
- Invariant #14 — every new affordance meets mobile workability.
- Repo wall — cross-product data flows ONLY through the frozen music seam.

---

### Feature 5.1 — Phase continuity on /events/:id
*The page knows where in time it is, even while open.*
- **S-5.1.1** Live-boundary transition *(3pts, CC)*
  Given /events/:id open in pre_event phase, when the phase boundary passes,
  then within 60s the page offers the live view (poll a lightweight phase
  endpoint; banner + soft swap, no full reload required). AC includes the
  event→post_event boundary equally. CSP-compliant script (nonce path).
- **S-5.1.2** Pre-event countdown affordance *(1pt, CC)*
  Given a future start_date, when the page renders, then a human-relative
  "starts in Xh" is shown server-side and ticks client-side. No timezone
  ambiguity: venue-local time labeled.
- **S-5.1.3** Display board phase parity *(2pts, CC)*
  Given /display auto-refresh, when an event crosses a phase boundary, then
  the board reflects the new phase within its existing 30s refresh SLA — same
  canonical resolver, asserted by test (no drift between surfaces).

### Feature 5.2 — Anonymous continuity (device-local only)
*"The system remembers for you" without the system knowing you.*
- **S-5.2.1** Device-local event memory *(3pts, CC)*
  Given a person views/registers/scans an event, when the page stores the
  event id + role marker in browser localStorage ONLY, then /public can show
  a "yours" rail from local state with explicit copy: "stored only on this
  device — we can't see this list." Anonymity affordance extended to say so.
  **CCR flag: human gate — copy wording is an Invariant #1 surface; Matt
  approves the exact language.**
- **S-5.2.2** Check-in day recall *(2pts, CC)*
  Given a registration confirmation code was issued, when the same device
  opens /events/:id during live phase, then the code surfaces from local
  storage with a one-tap copy — the Tuesday→Thursday seam closed with zero
  server linkage.
- **S-5.2.3** Clear-my-device control *(1pt, CC)*
  Given local memory exists, when "forget this device" is tapped, then all
  local state clears. Trust requires the exit.

### Feature 5.3 — Form flow closure
*No submission ends in a cul-de-sac.*
- **S-5.3.1** Registration → next-step card *(2pts, CC)*
  Given a successful registration, when the confirmation renders, then it
  offers: add-to-calendar (.ics download, server-generated), link back to the
  event page, and a one-line check-in explainer. AC: .ics opens correctly on
  iOS + Android.
- **S-5.3.2** Email signup → immediate payoff *(1pt, CC)*
  Given a signup succeeds, when confirmation renders, then the next-at-this-
  venue card (reuse the post-event query) shows immediately — the loop pays
  off before the first email ever sends.
- **S-5.3.3** Error states through @ocr/ui emptyState *(2pts, CC)*
  Given any form failure (duplicate, expired event, validation), when the
  error renders, then it uses the shared component with plain language and a
  recovery action. Negative-path suite extended to assert the action exists.

### Feature 5.4 — Organizer flow seamlessness (one-handed Thursday)
*P runs the room from a phone without Matt.*
- **S-5.4.1** Mint-and-share sponsor link in admin *(3pts, CC)*
  Given an event's sponsor list, when the organizer taps a sponsor, then a
  depth picker (Local/Mid/Premium) mints the signed link (S-3.1.2 claims) and
  opens the native share sheet. Thumb-reachable, ≥48px targets.
- **S-5.4.2** Link lifecycle visibility *(2pts, CC)*
  Given minted links, when the panel renders, then each shows depth + expiry
  + re-mint. **CCR flag: revocation of stateless HMAC tokens requires secret
  rotation or a denylist — v1 shows expiry only; revocation mechanics are a
  human-gated design decision.**
- **S-5.4.3** Optimistic headcount + offline queue *(5pts, CC)*
  Given spotty Eagles wifi, when headcount/session writes occur offline, then
  UI updates instantly, writes queue, and sync completes on reconnect (kill-
  wifi test from the spectrum scrum is the AC). Largest story in the epic;
  do not split casually — the queue and the optimism are one mechanism.

### Feature 5.5 — Cross-product seam surfacing (post-Pact only)
- **S-5.5.1** "What played" card on post-event recap *(2pts, CC)*
  Given Pact green on GET /api/events/:id/music (E2-F2.3 complete), when the
  post-event page renders and the flag is on, then the WKRP music layer shows
  as a recap card. Depends: S-2.2.1, S-2.3.1/2. The repo wall crossed ONLY at
  the sanctioned seam; failure of the seam degrades to no card, never an error.

### Feature 5.6 — Sponsor report seamlessness
*Proof → playbook → renewal without a phone call Matt has to remember.*
- **S-5.6.1** Upgrade affordance routes to a human *(2pts, CC)*
  Given upgrade.locked_sections renders (S-3.4.1), when the sponsor taps
  "ask about Mid," then a prefilled contact action (mailto/SMS to organizer,
  event + tier in the body) opens. No billing executes — **Invariant #6 by
  construction.**
- **S-5.6.2** Renewal loop on the report *(1pt, CC)*
  Given a sponsor views their report, when the next event at the venue
  exists, then the report shows it ("be there again") — the same query,
  third reuse, closing the sponsor's own return loop.
- **S-5.6.3** Organizer all-sponsor switcher *(2pts, CC)*
  Given an organizer-depth token, when viewing the report, then a sponsor
  switcher filters impressions per sponsor — the "organizer sees all,
  sponsor sees their slice" permission model made visible.

---

## Sequencing within the epic
1. 5.1 (phase continuity) + 5.3 (form closure) — pure OSE, no dependencies
2. 5.2 (device-local memory) — after CCR copy gate clears
3. 5.4 (organizer flows) — before the first P-run Thursday
4. 5.6 (report seamlessness) — after E3-F3.4 upgrade rendering
5. 5.5 (music card) — last; gated on Pact, flag-controlled

Total: 15 stories, ~32 points. Three CCR human gates: local-storage copy,
revocation mechanics, and (inherited) the upgrade contact wording.

## The acceptance test for the whole epic
One person, one phone, one week: sees the poster Tuesday, registers, gets the
calendar entry; opens the page Thursday at 6:58 and watches it go live at
7:00; checks in with the code the device remembered; comes back Friday to the
recap, sees what played and what's next; the sponsor gets their link from P's
share sheet and taps "ask about Mid." If any step requires remembering,
re-finding, or asking — the epic is not done.
